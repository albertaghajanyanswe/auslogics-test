import React, { useCallback, useEffect, useState } from "react";
import { Divider, Table, Checkbox } from "antd";
import qs from 'qs';
import type { CheckboxOptionType, TableProps } from "antd";
import { ColumnsType, DataType, TableParams } from "./types";
import useQueryParams from "./hooks/useQueryParams";


const columns: ColumnsType<DataType> = [
  {
    title: 'Name',
    dataIndex: 'name',
    sorter: true,
    render: (name) => `${name.first} ${name.last}`,
  },
  {
    title: 'Gender',
    dataIndex: 'gender',
    filters: [
      { text: 'Male', value: 'male' },
      { text: 'Female', value: 'female' },
    ],
    sorter: true
  },
  {
    title: 'Email',
    dataIndex: 'email',
    sorter: true
  },
  {
    title: "Flag",
    dataIndex: "gender",
    render: (flag, record) => {
      return (
        <Checkbox
          checked={flag === 'male'}
          disabled={true}
        />
      )
    },
    sorter: (a, b) => (a.registered.age === b.registered.age) ? 0 : a.registered.age ? -1 : 1,
  },
];

const getRandomuserParams = (params: TableParams) => ({
  results: params.pagination?.pageSize,
  page: params.pagination?.current,
  ...params,
});

const App: React.FC = () => {

  const [data, setData] = useState<DataType[]>();
  const [loading, setLoading] = useState(false);
  const [tableParams, setTableParams] = useState<TableParams>({
    pagination: {
      current: 1,
      pageSize: 10,
    },
  });
  const { queryParams, setFilteredParams } = useQueryParams({ pageDefaultParams: tableParams });

  const fetchData = useCallback(async () => {
    try {
      setLoading(true);
      const res = await fetch(`https://randomuser.me/api?${qs.stringify(getRandomuserParams(tableParams))}`);
      const resJSON = await res.json();
      setData(resJSON.results);
      setTableParams({
        ...tableParams,
        pagination: {
          ...tableParams.pagination,
          total: 2000,
        },
      });
    } catch (err) {
      // todo
    } finally {
      setLoading(false);
    }

  }, [tableParams]);

  useEffect(() => {
    fetchData();
  }, [JSON.stringify(tableParams)]);


  const handleTableChange: TableProps['onChange'] = (pagination, filters, sorter) => {
    const newFilter = {
      pagination,
      filters,
      ...sorter,
    };
    setTableParams(newFilter);

    if (pagination.pageSize !== tableParams.pagination?.pageSize) {
      setData([]);
    }

    // todo
    // setFilteredParams({params: newFilter})
  };

  const defaultCheckedList = columns.map((item) => {
    return item.title as string
  });
  const [checkedList, setCheckedList] = useState(defaultCheckedList);

  const options = columns.map(({ key, title }) => ({
    label: title,
    value: title,
  }));

  const newColumns = columns.map((item) => ({
    ...item,
    hidden: !checkedList.includes(item.title as string),
  }));

  return (
    <>
      <Divider>Columns displayed</Divider>
      <Checkbox.Group
        style={{ marginLeft: 24 }}
        value={checkedList}
        options={options as CheckboxOptionType[]}
        onChange={(value) => {
          setCheckedList(value as string[]);
        }}
      />

      <Table
        columns={newColumns}
        rowKey={(record) => record.login.uuid}
        dataSource={data}
        pagination={queryParams.params.pagination || tableParams.pagination}
        loading={loading}
        onChange={handleTableChange}
        style={{ marginTop: 24 }}
        scroll={{ y: 600 }}
      />
    </>
  );
};

export default App;