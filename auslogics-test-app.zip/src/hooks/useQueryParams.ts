import { useCallback, useRef } from 'react';
import qs from 'qs';
import { useLocation, useNavigate, useSearchParams } from 'react-router-dom';
import { TableParams } from '../types';

const useQueryParams = ({ pageDefaultParams }: { pageDefaultParams?: TableParams }) => {
  const location = useLocation();
  const navigate = useNavigate();
  const [, setSearchParams] = useSearchParams();

  const pageParams = qs.parse(location && location.search.split('?')[1], { ignoreQueryPrefix: true, arrayLimit: Infinity });

  const tableFilter = useRef(
    {
      params: {
        pagination: pageParams.pagination,
        sortField: pageParams.sortField,
        sortOrder: pageParams.sortOrder,
        filters: pageParams.filters,
      } as TableParams
    }
  );


  const replacePath = (newQuery: any) => {
    const search = qs.stringify({ ...newQuery }, { skipNulls: true });
    navigate(location.pathname);
    setSearchParams(search);
  };

  const setFilteredParams = useCallback(
    (newParams: {params: TableParams}) => {
      replacePath(newParams.params);
      tableFilter.current = { ...tableFilter.current, params: newParams.params };
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    []
  );

  return { queryParams: tableFilter.current, setFilteredParams }
};

export default useQueryParams;